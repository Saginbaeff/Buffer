#include <iostream>
#include <unordered_set>
#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <fstream>
#include <stdlib.h>
#include <fcntl.h>

struct cmp_rule_by_lval{
    char lvalue;
    explicit cmp_rule_by_lval(char init_sym){
        lvalue = init_sym;
    }
    bool operator()(std::pair<char, std::string> rule_to_check){
        return rule_to_check.first == lvalue;
    }
};

struct Situation{
    std::pair<char, std::string> situation_rule;
    int point;
    int letter_num;
    Situation(std::pair<char, std::string> init_rule, int init_point, int init_lnum){
        situation_rule = init_rule;
        point = init_point;
        letter_num = init_lnum;
    }
};

struct cmp_situations {
    bool operator()(const Situation &A, const Situation &B) const{
        if (A.situation_rule.first != B.situation_rule.first) {
            return A.situation_rule.first < B.situation_rule.first;
        }
        if (A.situation_rule.second != B.situation_rule.second) {
            return A.situation_rule.second < B.situation_rule.second;
        }
        if (A.point != B.point) {
            return A.point < B.point;
        }
        return A.letter_num < B.letter_num;
    }
};

std::vector<std::pair<char, std::string>> rules;
std::vector<std::set<Situation, cmp_situations>> D;

void scan(int j, std::string str){
    if (j == 0){
        return;
    }
    for (auto A = D[j - 1].begin(); A != D[j - 1].end(); ++A){
        if (A->situation_rule.second.length() <= A->point){
            continue;
        }
        if (A->situation_rule.second[A->point] == str[j - 1]){
            D[j].insert(Situation(A->situation_rule, A->point + 1, A->letter_num));
        }
    }
}

void complete(int j){
    for (auto B = D[j].begin(); B != D[j].end(); ++B){
        if (B->situation_rule.second.length() != B->point){
            continue;
        }
        for (auto A = D[B->letter_num].begin(); A != D[B->letter_num].end(); ++A){
            if (A->situation_rule.second[A->point] == B->situation_rule.first) {
                D[j].insert(Situation(A->situation_rule, A->point + 1, A->letter_num));
            }
        }
    }
}

void predict(int j){
    for (auto A = D[j].begin(); A != D[j].end(); ++A){
        if (A->situation_rule.second.length() <= A->point){
            continue;
        }
        auto seg_start = std::find_if(rules.begin(), rules.end(), cmp_rule_by_lval(A->situation_rule.second[A->point]));
        for (auto B = seg_start; B != rules.end() && B->first == A->situation_rule.second[A->point]; ++B){
            D[j].insert(Situation(*B, 0, j));
        }
    }
}

bool earley_algo(std::string str){
    for (int i = 0; i < str.length() + 1; ++i){
        scan(i, str);
        int sz = -1;
        while (D[i].size() != sz){
            sz = D[i].size();
            complete(i);
            predict(i);
        }
    }
    if (D[str.length()].count(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 1, 0))){
        return true;
    } else {
        return false;
    }
}

void test(){
    std::ifstream in;
    in.open("psp.txt");
    char grammar_rule_l;
    std::string grammar_rule_r;
    int rules_cnt;
    in >> rules_cnt;
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    D.clear();
    D.resize(11);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (earley_algo("(()()(()))")){
        std::cout << "TEST#1" << "[OK]\n";
    } else {
        std::cout << "TEST#1" << "[FAILED]\n";
    }
    D.clear();
    D.resize(10);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (!earley_algo("()()(()))")){
        std::cout << "TEST#2" << "[OK]\n";
    } else {
        std::cout << "TEST#2" << "[FAILED]\n";
    }
    in.close();
    in.open("prac2.txt");
    in >> rules_cnt;
    rules.clear();
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    D.clear();
    D.resize(4);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (earley_algo("cda")){
        std::cout << "TEST#3" << "[OK]\n";
    } else {
        std::cout << "TEST#3" << "[FAILED]\n";
    }
    D.clear();
    D.resize(5);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (!earley_algo("a")){
        std::cout << "TEST#4" << "[OK]\n";
    } else {
        std::cout << "TEST#4" << "[FAILED]\n";
    }
    in.close();
    in.open("prac1.txt");
    in >> rules_cnt;
    rules.clear();
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    D.clear();
    D.resize(4);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (earley_algo("cab")){
        std::cout << "TEST#5" << "[OK]\n";
    } else {
        std::cout << "TEST#5" << "[FAILED]\n";
    }
    D.clear();
    D.resize(5);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (!earley_algo("bac")){
        std::cout << "TEST#6" << "[OK]\n";
    } else {
        std::cout << "TEST#6" << "[FAILED]\n";
    }
    in.close();
    in.open("palindrom.txt");
    in >> rules_cnt;
    rules.clear();
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    D.clear();
    D.resize(12);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (earley_algo("babbaaabbab")){
        std::cout << "TEST#7" << "[OK]\n";
    } else {
        std::cout << "TEST#7" << "[FAILED]\n";
    }
    D.clear();
    D.resize(10);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (!earley_algo("aaaabbbbb")){
        std::cout << "TEST#8" << "[OK]\n";
    } else {
        std::cout << "TEST#8" << "[FAILED]\n";
    }
    in.close();
    in.open("arithm.txt");
    in >> rules_cnt;
    rules.clear();
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    D.clear();
    D.resize(10);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (earley_algo("(a+a)*a+a")){
        std::cout << "TEST#9" << "[OK]\n";
    } else {
        std::cout << "TEST#9" << "[FAILED]\n";
    }
    D.clear();
    D.resize(10);
    D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
    if (!earley_algo("*(a+a)*a+")){
        std::cout << "TEST#10" << "[OK]\n";
    } else {
        std::cout << "TEST#10" << "[FAILED]\n";
    }
    in.close();
}

int main(int argc, char* argv[]) {
    if (argc > 1 && argv[1][0] == '-' && argv[1][1] == 't') {
        test();
        return 0;
    }
    std::ifstream in;
    in.open(argv[1]);
    char grammar_rule_l;
    std::string grammar_rule_r;
    int rules_cnt;
    in >> rules_cnt;
    for (int i = 0; i < rules_cnt; ++i){
        in >> grammar_rule_l >> grammar_rule_r;
        rules.emplace_back(grammar_rule_l, grammar_rule_r.substr(2, grammar_rule_r.length() - 2));
    }
    std::string in_str;
    while (std::getline(std::cin, in_str)) {
        D.clear();
        D.resize(in_str.length() + 1);
        D[0].insert(Situation(std::pair<char, std::string>('S', std::string(1, rules[0].first)), 0, 0));
        if (earley_algo(in_str)){
            std::cout << "Accepted\n";
        } else {
            std::cout << "Rejected\n";
        }
    }
    return 0;
}